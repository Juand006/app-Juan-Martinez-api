import { clothes } from "./data";
import "./App.css";


function ClothesCard({item}) {
  return (
    <div className="card">
      <img src={item.images[0]} alt={item.title} className="card-img" />

      <div className="card-body">
        <h3 className="card-title">{item.title}</h3>
        <p className="card-price">${item.price}</p>
        <p className="card-description">{item.description}</p>

        <button className="btn">Ver más</button>
      </div>
    </div>
  );
}

export default function Profile() {
  return (
    <div className="grid">
      {clothes.map(item => (
        <ClothesCard key={item.id} item={item} />
      ))}
    </div>
  );
}
